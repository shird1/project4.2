import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loggedInUsers, setLoggedInUsers] = useState([]);
  const navigate = useNavigate();

  const handleJoinGame = (event) => {
    event.preventDefault();

    const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
    const user = existingUsers.find((user) => user.username === username && user.password === password);

    if (user) {
      const alreadyLoggedIn = loggedInUsers.find((u) => u.username === username);
      if (alreadyLoggedIn) {
        alert('User already logged in.');
      } else {
        setLoggedInUsers((prevUsers) => [...prevUsers, user]);
        setUsername(''); 
        setPassword(''); 
      }
    } else {
      alert('Invalid username or password.');
    }
  };

  const handleRegisterClick = () => {
    navigate('/register');
  };

  const handleStartGame = () => {
    // navigate to the board of the game
  };

  return (
    <div className="login-container">
      <h1>Login</h1>
      <form onSubmit={handleJoinGame}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Join the game</button>
      </form>
      <div className="register-link">
        New player? <span onClick={handleRegisterClick} className="register-text">Register</span>
      </div>
      <div>
        <h2>Join Us</h2>
        <ul>
          {loggedInUsers.map((user, index) => (
            <li key={index}>{user.username}</li>
          ))}
        </ul>
      </div>
      <button onClick={handleStartGame}>Start</button>
    </div>
  );
};

export default Login;
