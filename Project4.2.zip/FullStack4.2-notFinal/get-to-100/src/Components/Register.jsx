import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVerify, setPasswordVerify] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    if (password !== passwordVerify) {
      alert('Passwords do not match');
      return;
    }
    const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
    const newUser = { username, password };
    existingUsers.push(newUser);
    localStorage.setItem('users', JSON.stringify(existingUsers));
    navigate('/');
  };

  const handleLoginClick = () => {
    navigate('/');
  };

  return (
    <div className="register-container">
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="passwordVerify">Verify Password:</label>
          <input
            type="password"
            id="passwordVerify"
            value={passwordVerify}
            onChange={(e) => setPasswordVerify(e.target.value)}
            required
          />
        </div>
        <button type="submit">Register</button>
      </form>
      <div className="login-link">
        Already have an account? <span onClick={handleLoginClick} className="login-text" style={{color: 'blue', textDecoration: 'underline', cursor: 'pointer'}}>Login</span>
      </div>
    </div>
  );
};

export default Register;
